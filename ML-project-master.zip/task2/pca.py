import _pickle as cPickle
import numpy as np
from sklearn.decomposition import PCA

f = open('。/train.pkl', 'rb+')
info = cPickle.load(f)
footprint_train = np.unpackbits(info["packed_fp"], axis=1)
values = info['values']
# inf = np.unpackbits(footprint, axis=1)
np.set_printoptions(threshold=np.inf)
pca = PCA(n_components=256)
pca.fit(footprint_train)
print(pca.transform(footprint_train))