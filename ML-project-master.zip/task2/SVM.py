import numpy as np
import pandas as pd
import torch
import csv
from sklearn import svm
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score

def str_to_numpy(str):
    p = str.replace('\n', '').replace('.', '').replace(' ', '').strip('[').strip(']')
    return np.array(list(p), dtype=float)

df_train = pd.read_csv("D:\\python_codes\\samples\\train_used.csv")
df_test = pd.read_csv("D:\\python_codes\\samples\\test_used.csv")

x_train = []
x_test = []

x_tr = df_train['0']
for i in range(len(x_tr)):
    x_train.append(str_to_numpy(x_tr[i]))

y_train = df_train['1'].to_numpy()
x_te = df_test['0']
for i in range(len(x_te)):
    x_test.append(str_to_numpy(x_te[i]))

y_test = df_test['1'].to_numpy()

sgd_clf = SGDClassifier()
sgd_clf.fit(x_train, y_train)
y_pred = sgd_clf.predict(x_test)
score = accuracy_score(y_test, y_pred)
print(score)