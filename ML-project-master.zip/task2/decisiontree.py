import _pickle as cPickle
import numpy as np
from sklearn.tree import DecisionTreeRegressor
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.metrics import explained_variance_score
from sklearn.utils.multiclass import type_of_target


f1 = open('./train.pkl', 'rb+')
f2 = open('./test.pkl', 'rb+')
train = cPickle.load(f1)
test = cPickle.load(f2)
train_x_pre = train["packed_fp"]
train_y = train["values"]
train_x = np.unpackbits(train_x_pre, axis=1)
test_x_pre = test["packed_fp"]
test_y_0 = test["values"]
test_x = np.unpackbits(test_x_pre, axis=1)

test_y_1 = np.array(test_y_0, dtype=np.float64)
test_y = test_y_1.astype("int")
model = DecisionTreeRegressor(max_depth=50)
model.fit(train_x, train_y)
y_pred = model.predict(test_x)
score = explained_variance_score(test_y, y_pred)
print('evs: %.2f%%' % (score*100.0))


