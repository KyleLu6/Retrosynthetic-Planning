import numpy as np
import pandas as pd


train_data = pd.read_csv("train_sets.csv")
data = train_data.values.tolist()

# 用于将csv中的向量转化为narray


def str_to_numpy(str):
    p = str.replace('\n', '').replace('.', '').replace(' ', '').strip('[').strip(']')
    return np.array(list(p),dtype=float)


# 示例
# data每行第二列

arr = str_to_numpy(data[0][1])
np.set_printoptions(threshold=np.inf)
print(arr)
