import pandas as pd
import torch
import csv
from sklearn import preprocessing

le = preprocessing.LabelEncoder()

# 以DataFrame形式读取csv文件
df = pd.read_csv("D:\\python_codes\\samples\\test_sets.csv")

# 数据先转化为list
data_original = df['1'].tolist()
print(data_original)

# 使用fit_transform方法将一个字符串列表转换数值
target = le.fit_transform(data_original)

# 将数值转换为张量
targets = torch.as_tensor(target)
print(targets)


# 小改
result = targets.numpy()

# 写入csv文件中
file = open('config.csv', 'w')
writer = csv.writer(file)
writer.writerow(result)
file.close()

