""" Package for GUI extensions
"""
from .clustering import ClusteringGui  # noqa
