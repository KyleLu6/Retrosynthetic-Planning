def extract_smiles():
    return ["c1ccccc1", "Cc1ccccc1", "c1ccccc1", "CCO"]
