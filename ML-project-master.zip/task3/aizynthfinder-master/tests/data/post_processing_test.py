def post_processing(finder):
    return {"quantity": 5, "another_quantity": 10}
