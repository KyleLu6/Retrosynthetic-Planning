from setuptools import setup

import os
BASEPATH = os.path.dirname(os.path.abspath(__file__))

setup(name='mlp_retrosyn',
    py_modules=['mlp_retrosyn'],
    install_requires=[],
)
