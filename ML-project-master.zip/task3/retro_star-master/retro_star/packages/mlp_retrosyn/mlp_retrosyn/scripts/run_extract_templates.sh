python ../extract_template.py --data_folder '../data/toy/' \
  --file_name 'sample.csv'