from setuptools import setup

setup(
    name='retro_star',
    version='',
    packages=['retro_star'],
    url='',
    license='',
    author='binghong',
    author_email='binghong@gatech.edu',
    description='Retro* for retrosynthetic planning'
)